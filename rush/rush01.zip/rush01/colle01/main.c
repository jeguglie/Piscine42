/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   colle01.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jeguglie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/09 12:28:03 by jeguglie          #+#    #+#             */
/*   Updated: 2018/09/09 21:42:05 by jeguglie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>

void	print_sudoku(char *tab);
int		check_square(char *tab);
int		copy_square_top(char **tab, int count);
int		copy_square_middle(char **tab, int count);
int		copy_square_down(char **tab, int count);
int		launch_check(char **tab, int c);
int		check_args(char **argv);

char	**start_sudoku(int argc, char **argv, int c, int i)
{
	char	**tab;
	int		j;

	j = 0;
	if (!(tab = (char **)malloc(sizeof(*tab) * (9))))
		return (0);
	while (++c < 9)
		if (!(tab[c] = (char *)malloc(sizeof(**tab) * (9))))
			return (0);
	c = 0;
	if (argc != 10)
	{
		write(1, "ERROR : Invalid(s) arg(s).\n", 28);
		return (0);
	}
	while (argv[++j] && argc == 10)
	{
		while (argv[j][++i])
			tab[c][i] = argv[j][i];
		tab[c][i] = '\0';
		i = -1;
		c++;
	}
	return (tab);
}

char	**back_sudoku(char **tab, int pos)
{
	int		i;
	int		j;
	char	num;

	i = pos / 9;
	j = pos % 9;
	if (pos == 81)
		return (tab);
	if (tab[i][j] != 46)
		return (back_sudoku(tab, pos + 1));
	num = '0';
	while (++num <= 57)
	{
		if (launch_check(tab, 0))
		{
			tab[i][j] = num;
			if (back_sudoku(tab, pos + 1))
				return (back_sudoku(tab, pos + 1));
		}
	}
	tab[i][j] = 46;
	return (NULL);
}

int		main(int argc, char **argv)
{
	char	**tab;
	int		c;

	if (!(check_args(argv)))
	{
		write(1, "ERROR : Invalid(s) arg(s).\n", 28);
		return (0);
	}
	c = -1;
	if (!(tab = start_sudoku(argc, argv, -1, -1)))
		return (0);
	if (launch_check(tab, -1) != 1)
	{
		write(1, "LAUNCH CHECK : Same number.\n", 28);
		return (0);
	}
	back_sudoku(tab, 0);
	while (++c < 9)
		print_sudoku(tab[c]);
	return (0);
}
